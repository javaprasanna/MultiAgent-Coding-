# Fish Varieties Display Web Application

A static web application that displays various types of fish with their images and information.

## Features

- Display different fish varieties with their images
- Responsive design that works on all devices
- Interactive elements for better user experience
- Simple and clean interface

## Tech Stack

- Language: HTML, CSS, JavaScript
- Framework: Vue.js
- Frontend: Tailwind CSS
- Database: No database required (static content)

## Dependencies

- vue
- tailwindcss
- heroicons

## Architecture Notes

The application will be a single-page application using Vue.js for reactivity and components. Tailwind CSS will be used for styling and responsive design. Fish data will be stored in a static JSON file and rendered dynamically.

## Potential Conflicts

- No database integration since the application is static
- Limited functionality compared to a dynamic web application

## Setup

1. **Clone the repository:**

   ```bash
   git clone <repository-url>
   cd <repository-directory>
   ```

2. **Install dependencies:**

   ```bash
   npm install
   ```

3. **Configure Tailwind CSS:**

   Ensure that the `tailwind.config.js` and `postcss.config.js` files are correctly set up as shown below:

   **tailwind.config.js**

   ```javascript
   module.exports = {
     content: ['./src/**/*.{html,js,vue}', './public/index.html'],
   }
   ```

   **postcss.config.js**

   ```javascript
   module.exports = {
     plugins: {
       'tailwindcss': {},
       'autoprefixer': {},
     }
   }
   ```

## Run Instructions

1. **Start the development server:**

   ```bash
   npm run serve
   ```

2. **Open the application in your browser:**

   Navigate to `http://localhost:8080` to view the application.

## ASCII Architecture Diagram

```
+-------------------+
|   Frontend        |
|                   |
| +---------------+ |
| |   src         | |
| | +-----------+ | |
| | | assets    | | |
| | | components| | |
| | | router    | | |
| | | views     | | |
| | | App.vue   | | |
| | | main.js   | | |
| | +-----------+ | |
| +---------------+ |
| +---------------+ |
| | public        | |
| | index.html    | |
| | favicon.ico   | |
| +---------------+ |
+-------------------+
          |
          v
+-------------------+
|   Backend         |
|                   |
| (No backend code) |
+-------------------+
          |
          v
+-------------------+
|   Tests           |
|                   |
| +---------------+ |
| |   src         | |
| | +-----------+ | |
| | | components| | |
| | | router    | | |
| | | views     | | |
| | | App.vue   | | |
| | | main.js   | | |
| | +-----------+ | |
| +---------------+ |
+-------------------+
```

## Directory Tree

```
.
├── backend
├── config
│   ├── tailwind.config.js
│   └── postcss.config.js
├── frontend
│   ├── public
│   │   ├── index.html
│   │   └── favicon.ico
│   └── src
│       ├── assets
│       │   └── fishData.json
│       ├── components
│       ├── router
│       ├── views
│       ├── App.vue
│       └── main.js
└── tests
    └── src
        ├── components
        ├── router
        ├── views
        ├── App.vue
        └── main.js
```

## Files

- **frontend/src/main.js**: Entry point for the Vue.js application. Exports a Vue instance. Dependencies: vue.
- **frontend/src/App.vue**: Root component of the Vue.js application. Exports a Vue component. Dependencies: vue.
- **frontend/public/index.html**: HTML file for the Vue.js application. Exports an HTML document. Dependencies: none.
- **frontend/src/assets/fishData.json**: Static JSON file containing fish data. Exports JSON data. Dependencies: none.
- **config/tailwind.config.js**: Tailwind CSS configuration file. Exports Tailwind configuration. Dependencies: tailwindcss.
- **config/postcss.config.js**: PostCSS configuration file. Exports PostCSS configuration. Dependencies: tailwindcss.
- **tests/src/App.vue**: Test file for the root Vue component. Exports a Vue component test. Dependencies: vue.

## Contributing

Feel free to contribute to this project by submitting pull requests or opening issues. Your help is greatly appreciated!

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for more details.