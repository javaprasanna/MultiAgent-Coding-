<template>
  <div id="app">
    <h1>Test App Component</h1>
  </div>
</template>

<script>
export default {
  name: 'TestApp',
};
</script>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>