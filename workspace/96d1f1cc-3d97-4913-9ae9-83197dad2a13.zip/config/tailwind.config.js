module.exports = {
  content: [
    './frontend/src/**/*.{vue,js,ts,jsx,tsx}',
    './tests/src/**/*.{vue,js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};